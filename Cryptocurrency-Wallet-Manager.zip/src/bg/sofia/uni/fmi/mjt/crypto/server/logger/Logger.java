package bg.sofia.uni.fmi.mjt.crypto.server.logger;

public interface Logger {
    void logMessage(String message);
}
