package bg.sofia.uni.fmi.mjt.crypto.server.enums;

public enum TransactionType {
    SELL,
    BUY
}
