package bg.sofia.uni.fmi.mjt.crypto.server.util;

public class FileConstants {
    public static final String ERRORS_FILE = "resources/errors.txt";
    public static final String USERS_FILE = "resources/users.txt";
}
