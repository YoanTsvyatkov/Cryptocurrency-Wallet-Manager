package bg.sofia.uni.fmi.mjt.crypto.server.exception;

public class HttpException extends Exception {

    public HttpException(String message) {
        super(message);
    }
}
